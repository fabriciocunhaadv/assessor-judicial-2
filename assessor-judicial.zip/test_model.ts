import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
dotenv.config();

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
async function run() {
  try {
    await ai.models.generateContent({ model: "gemini-3.8-flash", contents: "hi" });
  } catch (err) {
    console.error(err);
  }
}
run();
